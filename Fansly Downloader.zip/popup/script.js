const helpButton = document.getElementById("help");
helpButton.addEventListener("click", () => {
    chrome.tabs.create(
        {
            url: `https://mail.google.com/mail/?view=cm&fs=1&to=support@sprise.ltd`,
        },
        function () {}
    );
});
