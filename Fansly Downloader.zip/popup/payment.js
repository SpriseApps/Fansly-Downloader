const paymentDiv = document.getElementById("payment");
const upgradeButton = document.getElementById("upgrade-btn");
const activateForm = document.getElementById("activate-form");
async function verifyLicense(licenseKey) {
    const res = await fetch("https://api.gumroad.com/v2/licenses/verify", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            product_permalink: "avrwl",
            license_key: licenseKey,
            increment_uses_count: false,
        }),
    });
    if (res.status !== 200) {
        return false;
    }
    const json = await res.json();
    return json.success;
}
window.addEventListener("load", async function (evt) {
    const storage = await chrome.storage.local.get();
    if (await verifyLicense(storage.license)) {
        window.location.href = "./index.html";
    } else {
        paymentDiv.classList.remove("hidden");
    }
});
upgradeButton.addEventListener("click", (event) => {
    event.preventDefault();
    chrome.tabs.create({
        url: "https://pancakesnipe.gumroad.com/l/avrwl",
    });
});
activateForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const fData = new FormData(activateForm);
    const licenseKey = fData.get("key");
    if (typeof licenseKey === "undefined" || licenseKey === null || licenseKey.length === 0) {
        return;
    }
    fetch("https://api.gumroad.com/v2/licenses/verify", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            product_permalink: "avrwl",
            license_key: licenseKey,
            increment_uses_count: false,
        }),
    }).then((res) => {
        if (res.status !== 200) {
            console.log(res.status);
            return;
        } else {
            res.json().then((json) => {
                if (json.success) {
                    chrome.storage.local.set({
                        license: licenseKey,
                    });
                    window.location.href = "./index.html";
                }
            });
        }
    });
});
