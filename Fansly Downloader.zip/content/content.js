async function verifyLicense(licenseKey) {
    const res = await fetch("https://api.gumroad.com/v2/licenses/verify", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            product_permalink: "avrwl",
            license_key: licenseKey,
            increment_uses_count: false,
        }),
    });
    if (res.status !== 200) {
        return false;
    }
    const json = await res.json();
    return json.success;
}

let function1 = (itemM, element) => {
    const closeBtn = itemM.getElementsByClassName("modal-close-button")[0];

    if (element.classList.contains("video-element-wrapper")) {
        element = element.querySelector(".video");
    }
    if (element.closest(".preview")) {
        return;
    }

    if (element.parentNode.querySelector(".modal-download-button") != null) {
        return;
    }

    if (closeBtn != null) {
        const btn = function3(closeBtn);
        btn.addEventListener("click", function4);

        function2(btn);

        element.parentNode.insertBefore(btn, element.nextSibling);
    }
};

let function2 = (element) => {
    element.style.setProperty("display", "flex", "important");
    element.style.setProperty("opacity", "1", "important");
};

let function3 = (closeBtn) => {
    const div = document.createElement("div");
    div.classList.add(...closeBtn.classList);
    div.classList.add("modal-download-button", "modal-pulse");
    div.setAttribute(closeBtn.attributes[0].name, closeBtn.attributes[0].value);
    const divIcon = document.createElement("i");
    divIcon.classList.add("fas", "fa-download");
    divIcon.setAttribute(closeBtn.attributes[0].name, closeBtn.attributes[0].value);
    div.appendChild(divIcon);
    return div;
};

let function4 = (event) => {
    const dldLink =
        event.path[2].querySelector(".video")?.src || event.path[2].querySelectorAll(".image")[1]?.src || event.path[2].querySelectorAll(".image")[0]?.src;

    const usn = "fansly";
    if (dldLink != null && !dldLink.includes("mp4")) {
        fetch(dldLink)
            .then((res) => res.text())
            .then((data) => {
                const type = function8(data.slice(0, 10));

                const name = usn + "-" + Math.random().toString(36).substr(2) + type;

                function11(dldLink, name);
            });
    } else if (dldLink != null && dldLink.includes("mp4")) {
        const name = usn + "-" + dldLink.split("/")[4].split("?")[0];

        function11(dldLink, name);
    }
};

let function5 = (feedElement) => {
    const hasM = function9(feedElement);
    if (hasM == false) {
        return;
    }

    const lastElem = feedElement.getElementsByClassName("feed-item-stats").length - 1;
    const stats = feedElement.getElementsByClassName("feed-item-stats")[lastElem];
    if (!stats || stats.querySelectorAll(".download").length > 0) {
        return;
    }

    const tBtn = stats.getElementsByClassName("tips")[0];
    if (tBtn != null) {
        const button = function6(tBtn);
        button.addEventListener("click", function7);

        function2(button);

        tBtn.parentNode.insertBefore(button, tBtn.nextSibling);
    }
};

let function6 = (tBtn) => {
    const btn = document.createElement("div");
    btn.classList.add(...tBtn.classList);
    btn.classList.replace("tips", "download");
    btn.setAttribute(tBtn.attributes[0].name, tBtn.attributes[0].value);
    const btnIconContainer = document.createElement("div");
    btnIconContainer.classList.add(...tBtn.children[0].classList);
    btnIconContainer.classList.replace("green", "pink");
    btnIconContainer.setAttribute(tBtn.attributes[0].name, tBtn.attributes[0].value);
    btn.appendChild(btnIconContainer);
    btn.appendChild(document.createTextNode("Download"));
    const btnIcon = document.createElement("i");
    btnIcon.classList.add("fas", "fa-download");
    btnIcon.setAttribute(tBtn.attributes[0].name, tBtn.attributes[0].value);
    btnIconContainer.appendChild(btnIcon);
    return btn;
};

let function7 = (event) => {
    event.stopPropagation();
    const fItmContent = event.path[2].closest(".feed-item-content");
    const preview = fItmContent.querySelectorAll(".feed-item-preview")[0];
    if (!preview.classList.contains("single-preview")) {
        preview.querySelectorAll(".image")[0].click();
        return;
    }
    dldLinks = function10(fItmContent);
    const usn = fItmContent.querySelector(".display-name").textContent.replace(/\s+/g, "");
    dldLinks.forEach((dldLink) => {
        if (dldLink.startsWith("img:")) {
            fetch(dldLink.substr(4))
                .then((res) => res.text())
                .then((data) => {
                    const type = function8(data.slice(0, 10));
                    const name = usn + "-" + Math.random().toString(36).substr(2) + type;
                    function11(dldLink.substr(4), name);
                });
        } else {
            const name = usn + "-" + dldLink.split("/")[4].split("?")[0];
            function11(dldLink.substr(4), name);
        }
    });
};

let function8 = (bString) => {
    let t = ".png";
    if (bString.includes("GIF")) {
        t = ".gif";
    } else if (bString.includes("JPG")) {
        t = ".jpg";
    } else if (bString.includes("JPEG")) {
        t = ".jpeg";
    }
    return t;
};

let function9 = (feedElement) => {
    let rVar = true;
    const preview = feedElement.querySelector(".feed-item-preview");
    if (preview) {
        let count = 0;
        const imageArray = preview.querySelectorAll(".image");
        for (let i = 0; i < imageArray.length; i++) {
            const img = imageArray[i].querySelector(".image");
            if (img != null && img.src != null) {
                count++;
            }
        }
        if (count == 0) {
            rVar = false;
        }
    } else if (!preview) {
        rVar = false;
    }
    return rVar;
};

let function10 = (feedElement) => {
    let rVar = [];
    const preview = feedElement.querySelector(".feed-item-preview");
    let video = false;
    if (preview.querySelectorAll(".video").length > 0) {
        video = true;
    }
    const imageArray = preview.querySelectorAll(".image");
    for (let i = 0; i < imageArray.length; i++) {
        if (imageArray[i].querySelector(".image") != null) {
            const img = imageArray[i].querySelector(".image");

            if (img.src != null && !video) {
                rVar.push("img:" + img.src);
            } else {
                const vid = preview.querySelector(".video");
                if (vid) {
                    rVar.push("vid:" + vid.src);
                }
            }
        }
    }

    return rVar;
};

let function11 = (url, name) => {
    if (url.includes("mp4")) {
        function16(url, name);
        return;
    }
    const downloadLink = document.createElement("a");
    downloadLink.href = url;
    downloadLink.setAttribute("download", name);
    document.body.appendChild(downloadLink);
    downloadLink.click();
    downloadLink.parentNode.removeChild(downloadLink);
};

let function12 = (name) => {
    const pItem = document.createElement("div");
    pItem.classList.add("item");
    pItem.innerText = name;
    const pBar = document.createElement("div");
    pBar.classList.add("progress");
    const pBarInner = document.createElement("div");
    pBar.appendChild(pBarInner);
    pItem.appendChild(pBar);
    return pItem;
};

let function13 = ({ loaded, total }, pItem) => {
    const value = Math.round((loaded / total) * 100) + "%";
    pItem.style.width = value;
    pItem.innerText = value;
};

let function14 = () => {
    const p = document.createElement("div");
    p.setAttribute("id", "progress-container");
    document.body.insertBefore(p, document.body.firstChild);
};

let function15 = (pItem, pBar) => {
    pBar.innerText = "Finished download!";
    pItem.style.transition = "opacity 1s ease-in 3s";
    pItem.style.opacity = 0;
    setTimeout(() => {
        pItem.parentNode.removeChild(pItem);
    }, 4000);
};

let function16 = async (url, name) => {
    const response = await fetch(url, {
        cache: "no-store",
        headers: new Headers({
            Origin: location.origin,
        }),
        mode: "cors",
    });
    const cLength = response.headers.get("content-length");
    const total = parseInt(cLength, 10);
    let loaded = 0;

    const res = new Response(
        new ReadableStream({
            async start(controller) {
                const reader = response.body.getReader();
                const pItem = function12(name);
                const p = document.getElementById("progress-container");
                p.insertBefore(pItem, p.firstChild);
                const pBar = pItem.querySelector(".progress").firstChild;
                for (;;) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    loaded += value.byteLength;
                    function13({ loaded, total }, pBar);
                    controller.enqueue(value);
                }
                controller.close();
                function15(pItem, pBar);
            },
        })
    );
    const blob = await res.blob();

    if (blob.size != 0) {
        let blobUrl = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = blobUrl;
        link.setAttribute("download", name);
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
    }
};

let function17 = () => {
    function14();
};

let function18 = (mutationsList) => {
    mutationsList.forEach((mutation) => {
        if (!mutation.addedNodes) return;
        for (let i = 0; i < mutation.addedNodes.length; i++) {
            const element = mutation.addedNodes[i];
            const classList = element.classList;

            if (classList == null) return;
            if (classList.contains("image")) {
                const feedElement = element.closest(".feed-item-content");
                if (feedElement) {
                    function5(feedElement);
                }

                const itemM = element.closest(".active-modal");
                if (itemM) {
                    function1(itemM, element);
                }
            }
        }
    });
};

const config = {
    attributes: true,
    childList: true,
    subtree: true,
    characterData: true,
};

const observer = new MutationObserver(function18);

window.addEventListener("load", async function () {
    const storage = await chrome.storage.local.get();
    if (await verifyLicense(storage.license)) {
        observer.observe(document.body, config);
        function17();
    }
});
